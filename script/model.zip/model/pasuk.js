var Pasuk = (function () {
    function Pasuk(str) {
        this.str = str;
        this.split();
        this.initialFlags();
    }
    Pasuk.prototype.split = function () {
        this.words = [];
        var word = "";
        for (var i = 0; i < this.str.length; i++) {
            if (this.str[i] == ' ') {
                this.words.push(word);
            } else if (this.str[i] == '\n' || this.str[i] == '-') {
            } else {
                word.concat(this.str[i]);
            }
        }
    };

    Pasuk.prototype.initialFlags = function () {
        this.flags = [];
        for (var i = 0; i < this.str.length; i++) {
            if (this.str[i] == ' ' || this.str[i] == '\n' || this.str[i] == '-') {
                this.flags.push(true);
            } else {
                this.flags.push(false);
            }
        }
    };

    Pasuk.prototype.getStr = function () {
        return this.str;
    };
    Pasuk.prototype.getWords = function () {
        return this.words;
    };
    Pasuk.prototype.getFlags = function () {
        return this.flags;
    };
    Pasuk.prototype.getFlag = function (index) {
        return this.flags[index];
    };
    Pasuk.prototype.getWord = function (index) {
        return this.words[index];
    };
    Pasuk.prototype.getLetter = function (index) {
        return this.str[index];
    };
    Pasuk.prototype.setFlag = function (index, check) {
        this.flags[index] = check;
    };
    Pasuk.prototype.getShownPasuk = function () {
        var show = this.str;
        for (var i = 0; i < show.length; i++) {
            if (this.getFlag(i) == false) {
                show[i] = '_';
            }
        }
        return show;
    };
    Pasuk.prototype.getPlainLetters = function () {
        var letters = [];
        for (var i = 0; i < this.str.length; i++) {
            if (this.str[i] != ' ' && this.str[i] != '-' && this.str[i] != '\n') {
                letters.push(this.str[i]);
            }
        }
        return letters;
    };
    return Pasuk;
})();
//# sourceMappingURL=pasuk.js.map
